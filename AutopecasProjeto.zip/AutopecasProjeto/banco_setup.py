# criar_banco.py
import sqlite3

conn = sqlite3.connect('banco.db')
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS pecas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    fabricante TEXT NOT NULL,
    preco REAL NOT NULL,
    estoque INTEGER NOT NULL
)
''')

pecas = [
    ('Filtro de óleo', 'BMW', 120.0, 10),
    ('Bateria', 'Audi', 600.0, 5),
    ('Pastilha de freio', 'Mercedes', 250.0, 8),
    ('Velas de ignição', 'Toyota', 180.0, 12),
    ('Amortecedor', 'Honda', 400.0, 6)
]

cursor.executemany('INSERT INTO pecas (nome, fabricante, preco, estoque) VALUES (?, ?, ?, ?)', pecas)

conn.commit()
conn.close()
print("Banco de dados criado com sucesso!")
