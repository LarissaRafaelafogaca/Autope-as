# servidor.py
import socket
import sqlite3

HOST = 'localhost'
PORT = 5050


def consulta_peca(fabricante, peca):
    try:
        conn = sqlite3.connect('banco.db')
        cursor = conn.cursor()
        print(f"[BD] Consultando: fabricante='{fabricante}', peça contendo '{peca}'")

        cursor.execute(
            "SELECT nome, preco, estoque FROM pecas WHERE fabricante = ? AND nome LIKE ?",
            (fabricante, f"%{peca}%")
        )
        resultado = cursor.fetchone()
        conn.close()

        if resultado:
            nome, preco, estoque = resultado
            if estoque > 0:
                return f"Disponível: {nome} - R${preco:.2f} (Estoque: {estoque})"
            else:
                return "Esgotado no estoque."
        else:
            return "Peça não encontrada para esse fabricante."

    except Exception as e:
        print(f"[ERRO BD - consulta_peca]: {e}")
        return "Erro na consulta."

def comprar_peca(fabricante, peca):
    try:
        conn = sqlite3.connect('banco.db')
        cursor = conn.cursor()
        print(f"[BD] Tentando comprar: fabricante='{fabricante}', peça contendo '{peca}'")

        cursor.execute(
            "SELECT nome, estoque FROM pecas WHERE fabricante = ? AND nome LIKE ?",
            (fabricante, f"%{peca}%")
        )
        resultado = cursor.fetchone()

        if resultado:
            nome, estoque = resultado
            if estoque > 0:
                novo_estoque = estoque - 1
                cursor.execute(
                    "UPDATE pecas SET estoque = ? WHERE fabricante = ? AND nome LIKE ?",
                    (novo_estoque, fabricante, f"%{peca}%")
                )
                conn.commit()
                conn.close()
                return f"Compra confirmada: {nome}. Novo estoque: {novo_estoque}"
            else:
                conn.close()
                return "Compra não realizada. Peça esgotada."
        else:
            conn.close()
            return "Peça não encontrada para esse fabricante."

    except Exception as e:
        print(f"[ERRO BD - comprar_peca]: {e}")
        return "Erro ao processar compra."

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((HOST, PORT))
        server_socket.listen()
        print(f"Servidor rodando em {HOST}:{PORT} ...")

        while True:
            conn, addr = server_socket.accept()
            with conn:
                print(f"\n[CONEXÃO] Cliente conectado: {addr}")
                try:
                    dados = conn.recv(1024).decode()
                    print(f"[REQUISIÇÃO] Mensagem recebida: {dados}")

                    if dados.startswith("CONSULTA|"):
                        _, fabricante, peca = dados.split("|")
                        resposta = consulta_peca(fabricante, peca)

                    elif dados.startswith("COMPRA|"):
                        _, fabricante, peca = dados.split("|")
                        resposta = comprar_peca(fabricante, peca)

                    else:
                        resposta = "Comando inválido."

                    print(f"[RESPOSTA] Enviando: {resposta}")
                    conn.sendall(resposta.encode())

                except Exception as e:
                    print(f"[ERRO GERAL] {e}")
                    conn.sendall("Erro no servidor.".encode())

if __name__ == "__main__":
    main()
