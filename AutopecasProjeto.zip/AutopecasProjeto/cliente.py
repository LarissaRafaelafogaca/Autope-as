import socket
import tkinter as tk
from tkinter import ttk, messagebox

fabricantes = ['BMW', 'Audi', 'Mercedes', 'Toyota', 'Honda']
pecas = ['Filtro', 'Bateria', 'Freio', 'Velas', 'Amortecedor', 'Óleo', 'Motor']  # busca parcial

SERVER_HOST = 'localhost'
SERVER_PORT = 5050

def consultar():
    nome_cliente = nome_entry.get().strip()
    fabricante = fabricante_combo.get()
    peca = peca_combo.get()

    if not nome_cliente:
        messagebox.showwarning("Aviso", "Digite o nome do cliente")
        return

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((SERVER_HOST, SERVER_PORT))
            mensagem = f"CONSULTA|{fabricante}|{peca}"
            print(f"[CLIENTE] Enviando: {mensagem}")
            s.sendall(mensagem.encode())
            resposta = s.recv(1024).decode()
            print(f"[CLIENTE] Recebido: {resposta}")
            messagebox.showinfo("Resposta do servidor", resposta)

    except socket.timeout:
        messagebox.showerror("Erro", "Tempo de resposta esgotado.")
    except ConnectionRefusedError:
        messagebox.showerror("Erro", "Servidor indisponível. Execute o servidor primeiro.")
    except Exception as e:
        messagebox.showerror("Erro inesperado", str(e))

def comprar():
    nome_cliente = nome_entry.get().strip()
    fabricante = fabricante_combo.get()
    peca = peca_combo.get()

    if not nome_cliente:
        messagebox.showwarning("Aviso", "Digite o nome do cliente")
        return

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((SERVER_HOST, SERVER_PORT))
            mensagem = f"COMPRA|{fabricante}|{peca}"
            print(f"[CLIENTE] Enviando: {mensagem}")
            s.sendall(mensagem.encode())
            resposta = s.recv(1024).decode()
            print(f"[CLIENTE] Recebido: {resposta}")
            messagebox.showinfo("Resposta do servidor", resposta)

    except socket.timeout:
        messagebox.showerror("Erro", "Tempo de resposta esgotado.")
    except ConnectionRefusedError:
        messagebox.showerror("Erro", "Servidor indisponível. Execute o servidor primeiro.")
    except Exception as e:
        messagebox.showerror("Erro inesperado", str(e))

# Interface gráfica
root = tk.Tk()
root.title("Cliente - Empresa de Autopeças")

tk.Label(root, text="Nome do Cliente:").pack()
nome_entry = tk.Entry(root)
nome_entry.pack()

tk.Label(root, text="Fabricante:").pack()
fabricante_combo = ttk.Combobox(root, values=fabricantes, state="readonly")
fabricante_combo.pack()
fabricante_combo.current(0)

tk.Label(root, text="Peça:").pack()
peca_combo = ttk.Combobox(root, values=pecas, state="readonly")
peca_combo.pack()
peca_combo.current(0)

btn_consultar = tk.Button(root, text="Consultar", command=consultar)
btn_consultar.pack(pady=5)

btn_comprar = tk.Button(root, text="Comprar", command=comprar)
btn_comprar.pack(pady=5)

root.mainloop()
